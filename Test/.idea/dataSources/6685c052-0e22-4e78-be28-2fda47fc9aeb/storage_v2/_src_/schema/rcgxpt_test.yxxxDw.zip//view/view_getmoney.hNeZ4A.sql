create definer = rcgxpt_test@`%` view view_getmoney as
select `rcgxpt_test`.`pt_user_money_detail`.`user_id`      AS `user_id`,
       `rcgxpt_test`.`pt_user_money_detail`.`change_value` AS `change_value`,
       `rcgxpt_test`.`pt_user_money_detail`.`update_by`    AS `update_by`,
       `rcgxpt_test`.`pt_user_money_detail`.`update_date`  AS `update_date`,
       `rcgxpt_test`.`pt_user_money_detail`.`remark`       AS `remark`,
       `rcgxpt_test`.`pt_user_money`.`money`               AS `money`,
       `rcgxpt_test`.`pt_user_money_detail`.`money_type`   AS `money_type`,
       `rcgxpt_test`.`pt_user_main`.`open_id`              AS `open_id`
from ((`rcgxpt_test`.`pt_user_money_detail` join `rcgxpt_test`.`pt_user_money`)
         join `rcgxpt_test`.`pt_user_main`)
where ((`rcgxpt_test`.`pt_user_money_detail`.`user_id` = `rcgxpt_test`.`pt_user_money`.`user_id`) and
       (`rcgxpt_test`.`pt_user_money_detail`.`user_id` = `rcgxpt_test`.`pt_user_main`.`main_id`));

-- comment on column view_getmoney.user_id not supported: 用户编码

-- comment on column view_getmoney.change_value not supported: 变动值

-- comment on column view_getmoney.update_by not supported: 更新者

-- comment on column view_getmoney.update_date not supported: 更新时间

-- comment on column view_getmoney.remark not supported: 备注

-- comment on column view_getmoney.money not supported: 金额

-- comment on column view_getmoney.money_type not supported: 变动类型

-- comment on column view_getmoney.open_id not supported: openId

