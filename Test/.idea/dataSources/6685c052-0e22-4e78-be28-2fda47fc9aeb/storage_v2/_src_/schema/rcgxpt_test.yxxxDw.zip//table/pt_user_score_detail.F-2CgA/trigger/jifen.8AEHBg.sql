create definer = rcgxpt_test@`%` trigger jifen
    after insert
    on pt_user_score_detail
    for each row
begin 
set @ls=concat(new.score_type,new.change_value);
 update pt_user_score set score_value=score_value+@ls where user_id=new.user_id; 
end;

